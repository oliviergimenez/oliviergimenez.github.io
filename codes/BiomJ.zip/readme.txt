"Parameter Redundancy in Multistate Capture-Recapture Models", Biometrical Journal
Olivier Gimenez, R�mi Choquet and Jean-Dominique Lebreton

Equipe Biom�trie et Biologie des Populations
Centre d�Ecologie Fonctionnelle et Evolutive CNRS
1919 route de Mende 
34293 Montpellier, FRANCE

corresponding author: olivier.gimenez@cefe.cnrs.fr

two files are provided:
"Maple_procedures.txt" = the Maple source codes for checking parameter-redundancy in capture-recapture models
"Maple_examples.txt" = the examples of the paper