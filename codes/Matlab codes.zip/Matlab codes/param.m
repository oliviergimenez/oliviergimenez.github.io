% function to calculate dataset characteristics
% mean value of the heterogenous parameter: mu
% heterogeneity coefficient: eta
% skewness coefficient: gamma
function [mu,eta,gamma]=param(pi,mu1,mu2,var1,var2)
mu=pi*mu1+(1-pi)*mu2
varintra=pi*var1+(1-pi)*var2 % intra-component variance 
varinter= pi*(mu1-mu)^2+(1-pi)*(mu2-mu)^2%inter-component variance 
vartot= varintra + varinter% total variance
eta=vartot/(mu*(1-mu))
gamma= (pi*(mu1-mu)^3+(1-pi)*(mu2-mu)^3)/sqrt(pi*(mu1-mu)^2+(1-pi)*(mu2-mu)^2)^3
end
