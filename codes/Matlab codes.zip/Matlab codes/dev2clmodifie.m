function lik = dev2clmodifie(b,data,eff,e,garb,s,k,m);

% function to calculate half-deviance of the 2-class CR model (uses multievent formulation)
% with the p's in decreasing order 
% p1 = p and p2 = p*delta with delta in [0;1] which implies p1 > p2

% data: CR data
% eff: nb of individuals with this particular CR history 
% e: vector of first capture
% garb: vector of initial states
% s: nb of states 
% k: nb of sampling occasions
% m: nb of observations

% misc
km1 = k-1;
nt=size(data,1);
nh=size(data,2);

% biological parameters
phi = 1./(1+exp(-b(1))); % survival
p=1./(1+exp(-b(2))); % detection
delta=1./(1+exp(-b(3))); % detection
propmix=1./(1+exp(-b(4))); % prop mixing in class 1

% events given states
B=zeros(2,3,km1);
for t = 1:km1
    B(:,:,t)=[1-p 1-(p*delta) 1;p p*delta 0];
end
BE=[0 0 1;1 1 0]; % output initiaux

% transitions between states
A=zeros(3,3,km1);
for t=1:km1
    A(:,:,t)=[phi 0 1-phi;0 phi 1 - phi;0 0 1];
end

% initial states distribution
PI=zeros(1,3,k);
for t=1:k
    PI(:,:,t)=[propmix 1-propmix 0];
end

lik=0;
for i=1:nh; 
    ei=e(i); % date of marking
    oe=garb(i)+1; % initial event
    evennt=data(:,i)+1;
        ALPHA=PI(:,:,ei).*BE(oe,:); 
        for j=(ei+1):nt
            ALPHA=(ALPHA*A(:,:,j-1)).*B(evennt(j),:,j-1);
        end
    lik=lik+logprot(sum(ALPHA))*eff(i);
end
lik=-lik;
