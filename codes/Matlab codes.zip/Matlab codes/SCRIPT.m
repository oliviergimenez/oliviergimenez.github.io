%% MATLAB script to 
%% 1) Simulate CR data with detection heterogeneity in a
%% short-lived species (scenario 1) with 60 generating distributions, 
%% 2) Fit the 1-class, 2-class and 3-class models to the data
%% 3) Calculate AIC, BIC and ICL for each of the 3 models.

%-----------------------------------------------------------------%
%------------------ 1) DATA SIMULATION ---------------------------%
%-----------------------------------------------------------------%

% general data parameters
Release= 10; %nb of release per occasion
nc=15; %nb of sampling occasion
km1=nc-1;
indiv=nc*Release; %nb of individuals
PHI = 0.60; % survival probability (constant parameter)
nbMC= 2; % number of MonteCarlo iterations
nbscenar=2; %nb of generating distributions

% parameters for the 60 generating distributions
PI1=repmat([0.5 0.2 0.8],1,20);%proportion of individuals in component 1
MU1 = [repmat(0.1,1,12), repmat(0.1,1,12), repmat(0.5,1,12), repmat(0.1,1,12), repmat(0.7,1,12)]; %mean detection for component 1
VAR1=repmat([repmat(0.0001,1,3) repmat(0.05,1,3) repmat(0.0001,1,3) repmat(0.05,1,3)],1,5); %intra-component variance 1
MU2 = [repmat(0.9,1,12), repmat(0.5,1,12), repmat(0.9,1,12), repmat(0.3,1,12), repmat(0.9,1,12)]; %mean detection for component 2
VAR2=repmat([repmat(0.0001,1,3) repmat(0.05,1,3) repmat(0.05,1,3) repmat(0.0001,1,3)],1,5); %intra-component variance 2
dataparam=[PI1;MU1;VAR1;MU2;VAR2]; % data parameters

% nb of model parameters
npcjs=2; %1-class model
np2cl=4; %2-class model
np3cl=6; %3-class model

%nb of criteria
nbcriteres=3;% aic, bic & icl

%% calculate the first catpure for each individual
first=[];
for i=1:nc
    first=[first; repmat(i,Release,1)];
end

%% initialization
betacomp1=zeros(2,nbscenar);% parameter of the beta distribution for component 1
betacomp2=zeros(2,nbscenar);%parameter of the beta distribution for component 2
res=zeros(3,nbscenar);% dataset characteristics (mu, eta and gamma)
valeurssimulees=zeros(indiv,nbMC,nbscenar);%values of detection simulated from the beta distribution
etat=zeros(indiv,nc,nbMC,nbscenar);% state
obs=zeros(indiv,nc,nbMC,nbscenar);% observations

betaCJS=zeros(npcjs,nbMC,nbscenar);% parameter estimates for the 1-class model
beta2cl=zeros(np2cl,nbMC,nbscenar);% parameter estimates for the 2-class model
beta3cl=zeros(np3cl,nbMC,nbscenar);% parameter estimates for the 3-class model

selcjs=zeros(nbcriteres,nbMC,nbscenar);% values of AIC, BIC and ICL for the 1-class model
sel2cl=zeros(nbcriteres,nbMC,nbscenar);% values of AIC, BIC and ICL for the 2-class model
sel3cl=zeros(nbcriteres,nbMC,nbscenar);% values of AIC, BIC and ICL for the 3-class model

tik2cl_1=zeros(indiv,nbMC,nbscenar); % individual probability of belonging to component 1 for the 2-class model
tik2cl_2=zeros(indiv,nbMC,nbscenar); % individual probability of belonging to component 1 for the 2-class model
tik3cl_1=zeros(indiv,nbMC, nbscenar);% individual probability of belonging to component 1 for the 3-class model
tik3cl_2=zeros(indiv,nbMC, nbscenar);% individual probability of belonging to component 2 for the 3-class model
tik3cl_3=zeros(indiv,nbMC, nbscenar);% individual probability of belonging to component 3 for the 3-class model

for j=1:nbscenar %for each generating distribution

% initialize
picomp1=[]; mucomp1=[]; varcomp1=[]; mucomp2=[]; varcomp2=[];
xfirst=[]; xsecond=[]; a1=[]; b1=[]; a2=[]; b2=[]; nb1=[]; nb2=[]; R1=[]; R2=[]; R=[];

% choose data parameters
picomp1=dataparam(1,j);%proportion of individuals in component 1
mucomp1 = dataparam(2,j); %mean detection for component 1
varcomp1=dataparam(3,j); %intra-component variance 1
mucomp2 = dataparam(4,j); %mean detection for component 2
varcomp2=dataparam(5,j); %intra-component variance 2

% calculate dataset characteristics (mu, eta, gamma)
% mean value of the heterogenous parameter : mutot
% heterogeneity coefficient: eta
% skewness coefficient: gamma
[mutot,eta,gamma]=param(picomp1,mucomp1,mucomp2,varcomp1,varcomp2);
res(:,j)=[mutot eta gamma];%save values of mu, eta and gamma

% make a starting guess at the solution
x0 = [1; 10]; 

%% parameters of the beta distributions for the 2 components
% first component
options=optimset('Display','iter'); % output options
xfirst = fsolve(@(x) myfun(x,mucomp1,varcomp1),x0,options);% optimization procedure
%second component
options=optimset('Display','iter'); % output options   
xsecond = fsolve(@(x) myfun(x,mucomp2,varcomp2),x0,options);% optimization procedure

%save beta parameters
betacomp1(:,j)=xfirst; %component 1
betacomp2(:,j)=xsecond; %component 2

%% simulate individual detection probability from the beta distribution
% first component
a1=xfirst(1); b1=xfirst(2); %parameters of the beta for component 1
nb1=picomp1*Release; %nb of individuals per cohort for component 1 
% second component
a2=xsecond(1); b2=xsecond(2); %parameters of the beta for component 2
nb2=Release-nb1;%nb of individuals per cohort for component 2 

for iter=1:nbMC % for each Monte Carlo iteration
P=[];    
for cohort=1:nc % for each cohort
    P=[P;betarnd(a1,b1,nb1,1);betarnd(a2,b2,nb2,1)];% draw individual detection for component 1 and 2
end
valeurssimulees(:,iter,j)=P; %save individual detection

%% simulate CR data
for i=1:indiv
    etat(i,first(i),iter,j)=1;
    obs(i,first(i),iter,j)=1;
    det=P(i);%detection probability for individual i
    for t=(first(i)+1):nc
        etat(i,t,iter,j)= etat(i,t-1,iter,j)*binornd(1,PHI,1); %state of individual i at occasion t
        obs(i,t,iter,j)= etat(i,t,iter,j)*binornd(1,det,1);%observation of individual i at occasion t
   end
end

%-----------------------------------------------------------------%
%---------------- MODEL FITTING and CALCULATION ------------------%
%----------------- of AIC, BIC and ICL for the -------------------%
%----------------------- 1-CLASS MODEL ---------------------------%
%-----------------------------------------------------------------%

% initialize
xvalCJS=[];
xval2cl=[];
xval3cl=[];
preproba2cl=[];
preproba3cl=[];
tik2cl=[];
tik3cl=[];
hist=[];

hist=obs(:,:,iter,j); %CR data

%% define data quantities
%initialize
ni=sum(hist);%nb of detection per occasion
eff=ones(indiv,1);%effectif
e=zeros(indiv,1);%first capture
last=zeros(indiv,1); %last capture
garb=zeros(indiv,1);

        for i=1:indiv
        e(i,1)=find(hist(i,:),1); 
        last(i,1)=find(hist(i,:),1,'last');
        garb(i,1)=hist(i,e(i,1));
        end
hist=hist';
nbiter=5000;
% define optimization paramters
opt=optimset('GradObj','off','HessUpdate','dfp','MaxIter',nbiter,'LargeScale','off',...
'TolFun',.0001,'TolX',.0001,'Display','iter','DerivativeCheck','off','Hessian','off','MaxFunEvals',50000);

%% fitting the 1-class model
s=2;m=2;% nb of states (s) and events (m)
init = [0.5 0.5];% initial values for parameter to be estimated
% optimization
xval=[];
[xval,fval,exitflag,output,grad,hessian] = fminunc_bis(@devCJS,init,opt,hist,eff,e,garb,s,nc,m);
betaCJS(:,iter,j)=xval;%save parameter estimates

aic=[];bic=[];icl=[];
%aic
aic=2*fval+2*npcjs;
%bic
bic=2*fval+npcjs*log(indiv);
%icl
icl=bic;%for the 1-class model, ICl = BIC because entropy is zero as the assignment confidence is perfect.

selcjs(:,iter,j)=[aic;bic;icl];% save AIC, BIC and ICL values for the 1-class model

%-----------------------------------------------------------------%
%---------------- MODEL FITTING and CALCULATION ------------------%
%----------------- of AIC, BIC and ICL for the -------------------%
%----------------------- 2-CLASS MODEL ---------------------------%
%-----------------------------------------------------------------%

s=3;m=2;% nb of states (s) and events (m)
init = [0.9 0.5 0.5 0.5]; % initial values for parameter to be estimated
% optimization
xval=[];
[xval,fval,exitflag,output,grad,hessian] = fminunc_bis(@dev2clmodifie,init,opt,hist,eff,e,garb,s,nc,m);
beta2cl(:,iter,j)=xval';%save parameter estimates
propmix=1./(1+exp(-xval(4))); % proportion of individual in component 1

%% Calculate AIC, BIC and ICL 

aic=[];bic=[];icl=[];
%AIC
aic=2*fval+2*np2cl;
%BIC
bic=2*fval+np2cl*log(indiv);       

%ICL
%part 1
b=[xval(1) xval(2)]; %survival and detection estimate for component 1
prclass1 = probaCJS(b,hist,eff,e,garb,s,nc,m);%individual probability of belonging to component 1
%part 2
b =[xval(1) xval(2) xval(3)]; %survival and detection estimate for component 2
prclass2 = probaCJSphideltaDETECTION(b,hist,eff,e,garb,s,nc,m);%individual probability of belonging to component 1

preproba2cl=[preproba2cl; prclass1 prclass2];%save individual probability of belonging to each component

%individual probability of belonging to each component
ti1 = (propmix .* prclass1) ./ (propmix .*prclass1 + (1-propmix) .* prclass2);%component 1
ti2 = ((1-propmix) .* prclass2) ./ (propmix .*prclass1 + (1-propmix) .* prclass2);%component 2

tik2cl_1(:,iter,j)=ti1;
tik2cl_2(:,iter,j)=ti2;

EN = - sum(ti1.*log(ti1) + ti2.*log(ti2));%calculate entropy
icl=bic+2*EN;%calculate ICL

sel2cl(:,iter,j)=[aic;bic;icl];%save values of AIC, BIC and ICL for the 2-class model

%-----------------------------------------------------------------%
%---------------- MODEL FITTING and CALCULATION ------------------%
%----------------- of AIC, BIC and ICL for the -------------------%
%----------------------- 3-CLASS MODEL ---------------------------%
%-----------------------------------------------------------------%

s=4;m=2;% nb of states (s) and events (m)
init = [0.9 0.5 0.5 0.5 0.5 0.5]; % inits for parameters to be estimated
% optimization
xval=[];
[xval,fval,exitflag,output,grad,hessian] = fminunc_bis(@dev3clmodifie,init,opt,hist,eff,e,garb,s,nc,m);
beta3cl(:,iter,j)=xval';%save parameter estimates


propmix1= exp(xval(5))./ (1+exp(xval(6)) + exp(xval(5)));% proportion of individuals in component 1
propmix2= exp(xval(6))./ (1+exp(xval(6)) + exp(xval(5)));% proportion of individuals in component 2
propmix3=1-(propmix1+propmix2); % proportion of individuals in component 3

%% calculate AIC, BIC and ICL
aic=[];bic=[];icl=[];
%AIC
aic=2*fval+2*np3cl;
%BIC
bic=2*fval+np3cl*log(indiv);

% ICL
%part 1
b=[xval(1) xval(2)]; %survival and detection estimate for component 1
prclass1 = probaCJS(b,hist,eff,e,garb,s,nc,m);

%part 2
b =[xval(1) xval(2) xval(3)]; %survival and detection estimate for component 2
prclass2 = probaCJSphideltaDETECTION(b,hist,eff,e,garb,s,nc,m);

%part 3
b=[xval(1) xval(2) xval(3) xval(4)]; %survival and detection estimate for component 3
prclass3 = probaCJSphideltadeltaprimeDETECTION(b,hist,eff,e,garb,s,nc,m);
%individual probability of belonging to each component
ti1 = (propmix1 .* prclass1) ./ (propmix1 .*prclass1 + propmix2 .*prclass2 + propmix3 .* prclass3);%component 1
ti2 = (propmix2 .* prclass2) ./ (propmix1 .*prclass1 + propmix2 .*prclass2 + propmix3 .* prclass3);%component 2
ti3 = (propmix3 .* prclass3) ./ (propmix1 .*prclass1 + propmix2 .*prclass2 + propmix3 .* prclass3);%component 3

tik3cl_1(:,iter,j)=ti1;
tik3cl_2(:,iter,j)=ti2;
tik3cl_3(:,iter,j)=ti3;


EN = - sum(ti1.*log(ti1) + ti2.*log(ti2) + ti3.*log(ti3));%calculate entropy
icl=bic+2*EN;%calculate ICL

sel3cl(:,iter,j)=[aic;bic;icl];%save values of the criteria for the 3-class mdoel

end

end

%-----------------------------------------------------------------%
%----------------------- DISPLAY RESULTS -------------------------%
%-----------------------------------------------------------------%
% parameters estimates for each model (1-, 2- and 3-class)
% and associated AIC, BIC and ICL values

% arrays of dim nb of parameters x nb of Monte Carlo simulations x nb of scenarios
betaCJS% parameter estimates for the 1-class model 
beta2cl% parameter estimates for the 2-class model
beta3cl% parameter estimates for the 3-class model

% arrays of dim nb of model selection criteria x nb of Monte Carlo simulations x nb of scenarios
selcjs% values of AIC, BIC and ICL for the 1-class model
sel2cl% values of AIC, BIC and ICL for the 2-class model
sel3cl% values of AIC, BIC and ICL for the 3-class model

