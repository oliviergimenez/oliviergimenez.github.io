################################################################################################
###											     ###
### MATLAB functions to 								     ###
###											     ###
### 1) Simulate capture-recapture data with detection heterogeneity in a short-lived species ###
### (scenario 1) with 60 generating distributions ##############################################
### 											     ###
### 2) Fit the 1-class, 2-class and 3-class models to these data 			     ###
### 											     ###
### 3) Calculate AIC, BIC and ICL for each of the 3 models.				     ###
###											     ###
### Sarah Cubaynes, April 2011								     ###
###											     ###
################################################################################################

- master file is SCRIPT.m which performs the 3 steps above. It requires several functions 
to run:

- functions devCJS.m, dev2clmodifie.m and dev3clmodifie.m which calculate the deviance for 
the 1-class, 2-class and 3-class models (resp.);

- probaCJS.m, probaCJSphideltaDETECTION.m and probaCJSphideltadeltaprimeDETECTION.m which 
calculate the probability of each capture history under the 1-class, 2-class and 3-class 
models (resp.)

- fminunc_bis.m, fminusub_bis.m, cubici2_bis.m, cubici3_bis.m, optimfcnchk_bis.m, 
searchq_bis.m which are related to the optimization procedure

- logprot.m, myfun.m, param.m which perform various secondary calculations


