function lik = devCJS(b,data,eff,e,garb,s,k,m);

% function to calculate half-deviance of the 1-class CR model (uses multievent formulation)
% data: CR data
% eff: nb of individuals with this particular CR history 
% e: vector of first capture
% garb: vector of initial states
% s: nb of states 
% k: nb of sampling occasions
% m: nb of observations (here, two, i.e. 'detected' and 'non detected')

% misc
km1 = k-1;
nt=size(data,1);
nh=size(data,2);

% biological parameters
phi = 1./(1+exp(-b(1))); % survival
p=1./(1+exp(-b(2))); % detection

% events given states
B=zeros(2,2,km1);
for t = 1:km1
    B(:,:,t)=[1-p 1;p 0];
end
BE=[0 1;1 0]; % initial outputs

% transitions between states
A=zeros(2,2,km1);
for t=1:km1
    A(:,:,t)=[phi 1 - phi;0 1];
end

% initial states distribution
PI=zeros(1,2,k);
for t=1:k
    PI(:,:,t)=[1 0];
end

lik=0;
for i=1:nh; 
    ei=e(i); % marking date
    oe=garb(i)+1; % initial event
    evennt=data(:,i)+1;
        ALPHA=PI(:,:,ei).*BE(oe,:); 
        for j=(ei+1):nt
            ALPHA=(ALPHA*A(:,:,j-1)).*B(evennt(j),:,j-1);
        end
    lik=lik+logprot(sum(ALPHA))*eff(i);
end
lik=-lik;
