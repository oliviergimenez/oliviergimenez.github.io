function u=logprot(v);
%============= log protected for small values of v
% INPUT v
%======================================================
% OUTPUT u=log(v) for large value of v
%======================================================
% uses .
%======================================================
% last modified RC 07.12.2000
%======================================================
u=log(eps)*ones(size(v));
index=find(v>eps);
u(index)=log(v(index));
clear index;