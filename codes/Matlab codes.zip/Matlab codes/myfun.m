% function to solve the 2x2 system 
% and get parameters of the genetrating beta distributions
function F = myfun(x,mu,var)
F = [mu- x(1) /(x(1)+x(2));
      var- (x(1)*x(2))/((x(1)+x(2)+1)*(x(1)+x(2))^2)];
end
