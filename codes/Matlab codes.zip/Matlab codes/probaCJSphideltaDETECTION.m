function prob = probaCJSphideltaDETECTION(b,data,eff,e,garb,s,k,m);

% Function to calculate the probability of each CR history
% under the 2-class model

% data: CR data
% eff: nb of individuals with this particular CR history 
% e: vector of first capture
% garb: vector of initial states
% s: nb of states 
% k: nb of sampling occasions
% m: nb of observations

% misc
km1 = k-1;
nt=size(data,1);
nh=size(data,2);

% biological parameters
phi = 1./(1+exp(-b(1))); % survival
p = 1./(1+exp(-b(2))); % detection
delta=1./(1+exp(-b(3))); 

% events given states
B=zeros(2,2,km1);
for t = 1:km1
    B(:,:,t)=[1-(p*delta) 1;p*delta 0];
end
BE=[0 1;1 0]; % initial outputs

% transition between states
A=zeros(2,2,km1);
for t=1:km1
    A(:,:,t)=[phi 1-phi;0 1];
end

% initial states distribution
PI=zeros(1,2,k);
for t=1:k
    PI(:,:,t)=[1 0];
end

prob=[];
for i=1:nh; 
    ei=e(i); % date of marking
    oe=garb(i)+1; % initial event
    evennt=data(:,i)+1;
        ALPHA=PI(:,:,ei).*BE(oe,:); 
        for j=(ei+1):nt
            ALPHA=(ALPHA*A(:,:,j-1)).*B(evennt(j),:,j-1);
        end
    prob=[prob; sum(ALPHA)];
end