######################################################################################################
################# simulate data ######################################################################
######################################################################################################

# detection probability
p = 0.8

# nb of individuals
N = 100

# nb of capture occasions
Years = 5

# generate ecounter histories
h <- matrix(0,nrow=N,ncol=Years)
h[,1] = 1 # to make it simple, a single cohort starting on the 1st year
alive = h # matrix of states (alive = 1, dead = 0)
phi <- rep(0,N)

# two covariates
x1 <- rnorm(N,0,1)
x2 <- rnorm(N,0,1)

for (i in 1:N)
{

	# linear effect of x2, quadratic effect of x2 and nonlinear effect of x1 and x2 ; indiv random effect with SD=0.5
	phi[i] = 1/(1+exp(-(0 + 0 * x1[i] - 0.188 * x2[i] + 0 * x1[i]^2 - 0.220 * x2[i]^2 + 0.5 * x2[i] * x2[i] 
						- 1.67 * x1[i] * x2[i] + rnorm(1,mean=0,sd=.5))))
	for (j in 1:(Years-1))
	{
		alive[i,j+1] <- rbinom(1,1,phi[i]*alive[i,j]) # if i is alive at j, alive at j+1 with proba phi[i], 
													  # otherwise, if dead at j, alive with proba 0 at j+1
		h[i,j+1] <- rbinom(1,1,p*alive[i,j+1]) # if i is alive at j+1, detected at j+1 with proba p, 
											   # otherwise, if dead at j+1, detected with proba 0 at j+1
	}
}

# display encounter histories
h

# histogram of survival probs
hist(phi)


######################################################################################################
################# misc computations ##################################################################
######################################################################################################
# specify the working directory
setwd("/Users/oliviergimenez/Desktop/wiki/splines")

# covariates
cov=cbind(x1,x2)

# number of individuals 
N <- dim(h)[[1]] 

# number of years
Years <- dim(h)[[2]]

# compute the date of first capture
First <- NULL
for (i in 1:N)
{
	temp <- 1:Years
	First <- c(First,min(temp[h[i,]==1]))
}

# inits for the states
Xinit <- matrix(NA,nrow=N,ncol=Years)
for (i in 1:N)
{
	for (j in 1:(Years))
	{
		if (j > First[i]) Xinit[i,j] <- 1
	}
}

######################################################################################################
################# linear gradients ###################################################################
######################################################################################################

# data
datax <- list(N=N,Years=Years,dat=as.matrix(h),First=First,cov=cov)

# first list of inits
init1 <- list(p = 0.2,alive=as.matrix(Xinit),mu=.5)
# second list of inits
init2 <- list(p = 0.8,alive=as.matrix(Xinit),mu=-.5)

# concatenate initial values
inits <- list(init1,init2)

# load rjags package
library(rjags)
load.module('glm')

# store the starting point
deb = Sys.time()

# MCMC simulations 
model <- jags.model(file = "MRlinear.bug", data = datax, inits = inits, n.chains = 2) 

# post inference
mcmc <- coda.samples(model, c("p","sigmaeps","mu","beta"), n.iter = 2000) 

# store the ending point
fin = Sys.time()

# duration of the run 
duration=fin - deb
duration

# check convergence
plot(mcmc, trace = TRUE, density = FALSE,ask = dev.interactive())
gelman.diag(mcmc)

# display posterior estimates
summary(mcmc)

# plot posterior distributions
plot(mcmc, trace = FALSE, density = TRUE,ask = dev.interactive()) 

# save results
save(mcmc,duration,file='lin.Rdata')


#------ model selection - � la Kuo & Mallick (see Royle 2008 in Biometrics for implementation)
library(rjags)
load.module('glm')
datax <- list(N=N,Years=Years,dat=as.matrix(h),First=First,cov=cov)
init1 <- list(p = 0.2,alive=as.matrix(Xinit),mu=.5,w=rep(0,2))
init2 <- list(p = 0.8,alive=as.matrix(Xinit),mu=-.5,w=rep(1,2))
inits <- list(init1,init2)
model <- jags.model(file = "MRlinear-withMS.bug", data = datax, inits = inits, n.chains = 2) 
mcmc <- coda.samples(model, c("p","sigmaeps","mu","beta","w"), n.iter = 2000) 

# post prob for cov
w1 = c(mcmc[[1]][,'w[1]'],mcmc[[2]][,'w[1]'])
w2 = c(mcmc[[1]][,'w[2]'],mcmc[[2]][,'w[2]'])
mean(w1)
mean(w2)

# post model prob
mean(w1 == 1 & w2 == 1)
mean(w1 == 1 & w2 == 0)
mean(w1 == 0 & w2 == 1)
mean(w1 == 0 & w2 == 0)

######################################################################################################
################# nonlinear gradients ###################################################################
######################################################################################################

# covariates
cov=cbind(x1,x2)

# data
datax <- list(N=N,Years=Years,dat=as.matrix(h),First=First,cov=cov)

# first list of inits
init1 <- list(p = 0.2,alive=as.matrix(Xinit),mu=.5)
# second list of inits
init2 <- list(p = 0.8,alive=as.matrix(Xinit),mu=-.5)

# concatenate initial values
inits <- list(init1,init2)

# load rjags package
library(rjags)
load.module('glm')

# store the starting point
deb = Sys.time()

# MCMC simulations 
model <- jags.model(file = "MRnonlinear.bug", data = datax, inits = inits, n.chains = 2) 

# post inference
mcmc <- coda.samples(model, c("p","sigmaeps","mu","beta"), n.iter = 2000) 

# store the ending point
fin = Sys.time()

# duration of the run 
duration=fin - deb # approx. ? minutes (2.66Ghz, 736Mo RAM)
duration

# check convergence
plot(mcmc, trace = TRUE, density = FALSE,ask = dev.interactive())
gelman.diag(mcmc)

# display posterior estimates / compare with values used to generate data

summary(mcmc)

# plot posterior distributions
plot(mcmc, trace = FALSE, density = TRUE,ask = dev.interactive()) 

# save results
save(mcmc,duration,file='nonlin.Rdata')


#------ model selection
library(rjags)
load.module('glm')
datax <- list(N=N,Years=Years,dat=as.matrix(h),First=First,cov=cov)
init1 <- list(p = 0.2,alive=as.matrix(Xinit),mu=.5,w=rep(0,3))
init2 <- list(p = 0.8,alive=as.matrix(Xinit),mu=-.5,w=rep(1,3))
inits <- list(init1,init2)
model <- jags.model(file = "MRnonlinear-withMS.bug", data = datax, inits = inits, n.chains = 2) 
mcmc <- coda.samples(model, c("p","sigmaeps","mu","beta","w"), n.iter = 2000) 

# post prob for cov
w1 = c(mcmc[[1]][,'w[1]'],mcmc[[2]][,'w[1]'])
w2 = c(mcmc[[1]][,'w[2]'],mcmc[[2]][,'w[2]'])
w3 = c(mcmc[[1]][,'w[3]'],mcmc[[2]][,'w[3]'])

mean(w1)
mean(w2)
mean(w3)

# post model prob
mean(w1 == 1 & w2 == 1 & w3 == 1)
mean(w1 == 0 & w2 == 1 & w3 == 1)
mean(w1 == 1 & w2 == 0 & w3 == 1)
mean(w1 == 1 & w2 == 1 & w3 == 0)
mean(w1 == 0 & w2 == 0 & w3 == 1)
mean(w1 == 0 & w2 == 1 & w3 == 0)
mean(w1 == 1 & w2 == 0 & w3 == 0)
mean(w1 == 0 & w2 == 0 & w3 == 0)



######################################################################################################
################# splines smoothing ##################################################################
######################################################################################################

# load package to build up grid 
library(fields)

# max(20,min(N/4,150)), n is for unique combinations of x1 and x2 only
nknotsb=25

tps.cov<-function(r)
{
	r<-as.matrix(r)
	num.row<-nrow(r)
	num.col<-ncol(r)
	r<-as.vector(r)
	nzi<-(1:length(r))[r!=0]
	ans<-rep(0,length(r))
	ans[nzi]<-r[nzi]^2*log(abs(r[nzi]))
	if (num.col>1) ans<-matrix(ans,num.row,num.col)
	return(ans)
	
}

R<-cbind(x1,x2+0.001*rnorm(length(x2)))
knots.Fields<-cover.design(R,nknotsb)
knots.Fields<-knots.Fields$design[,]

#Define the fixed effect matrices
Xfix<-cbind(rep(1,length(x1)),x1,x2)
Xsigma<-cbind(rep(1,nknotsb),knots.Fields)


#Obtain the matrix of random effects 
#This is for the mean function (thin plate splines)
dist.mat_all<-matrix(0,nknotsb,nknotsb)
dist.mat_all[lower.tri(dist.mat_all)]<-dist(knots.Fields)


dist.mat_all<-dist.mat_all+t(dist.mat_all)
OMEGA_all<-tps.cov(dist.mat_all)
diffs.1_all<-outer(Xfix[,2],knots.Fields[,1],"-")
diffs.2_all<-outer(Xfix[,3],knots.Fields[,2],"-")
dists_all<-sqrt(diffs.1_all^2+diffs.2_all^2)


svd.OMEGA_all<-svd(OMEGA_all)
sqrt.OMEGA_all<-t(svd.OMEGA_all$v %*% (t(svd.OMEGA_all$u)*sqrt(svd.OMEGA_all$d)))
Z<-t(solve(sqrt.OMEGA_all,t(tps.cov(dists_all))))


# data
datax <- list(N=N,Years=Years,dat=as.matrix(h),First=First,Xfix=Xfix,Z=Z,nknotsb=nknotsb)

# first list of inits
init1 <- list(p = 0.2,alive=as.matrix(Xinit))
# second list of inits
init2 <- list(p = 0.8,alive=as.matrix(Xinit))

# concatenate initial values
inits <- list(init1,init2)

# load rjags package
library(rjags)
load.module('glm')

# store the starting point
deb = Sys.time()

# MCMC simulations 
model <- jags.model(file = "MRsplines.bug", data = datax, inits = inits, n.chains = 2) 

# post inference
mcmc <- coda.samples(model, c("p","sigmaeps","sigmab","b","beta"), n.iter = 2000) 

# store the ending point
fin = Sys.time()

# duration of the run 
duration=fin - deb # approx. ? minutes (2.66Ghz, 736Mo RAM)
duration

# check convergence
plot(mcmc, trace = TRUE, density = FALSE,ask = dev.interactive())
gelman.diag(mcmc)

# display posterior estimates / compare with values used to generate data
summary(mcmc)

# plot posterior distributions
plot(mcmc, trace = FALSE, density = TRUE,ask = dev.interactive()) 

# save results
save(mcmc,duration,file='splines.Rdata')


######################################################################################################
################# graphical repres ###################################################################
######################################################################################################

### prediction from splines model
load('splines.Rdata')

beta <- cbind(
c(mcmc[[1]][,'beta[1]'],mcmc[[2]][,'beta[1]']),
c(mcmc[[1]][,'beta[2]'],mcmc[[2]][,'beta[2]']),
c(mcmc[[1]][,'beta[3]'],mcmc[[2]][,'beta[3]'])
)

observed_fixed_mean <- Xfix %*% t(beta)

b <- NULL
for (i in 1:25)
{
	temp <- c(mcmc[[1]][,paste('b[',i,']',sep = "")],mcmc[[2]][,paste('b[',i,']',sep = "")])
	b <- cbind(b,temp)
}

observed_random_mean <- Z %*% t(b)
observed_matrix_logit_mean <- observed_fixed_mean+observed_random_mean
mean.fitted.values = matrix(0,nrow=1,ncol=N)
for (i in 1:N)
{
	mean.fitted.values[1,i]<-mean(1/(1+exp(-observed_matrix_logit_mean[i,])),na.rm = TRUE)
}

# build a grid and predict survival at each point of the grid
lgrid=25 # 25x25 grid
cov1.min = range(x1)[1] - (range(x1)[2]-range(x1)[1])*.1
cov1.max = range(x1)[2] + (range(x1)[2]-range(x1)[1])*.1
cov2.min = range(x2)[1] - (range(x2)[2]-range(x2)[1])*.1
cov2.max = range(x2)[2] + (range(x2)[2]-range(x2)[1])*.1

WB_mean_mean<-matrix(rep(0,lgrid*lgrid),lgrid,lgrid)
WB_sd_mean<-WB_mean_mean


for (i in 1:lgrid)
{
	
# updating using the chains simulated from the posterior distributions
	X0=cbind(rep(1,lgrid),seq(cov1.min,cov1.max,len=lgrid)[i],seq(cov2.min,cov2.max,len=lgrid))
	differences.1_all<-outer(X0[,2],knots.Fields[,1],"-")
	differences.2_all<-outer(X0[,3],knots.Fields[,2],"-")
	distances_all<-sqrt(differences.1_all^2+differences.2_all^2)
	Z0<-t(solve(sqrt.OMEGA_all,t(tps.cov(distances_all))))
	
	
# updating the mean
	auxiliary_fixed_mean<-X0 %*% t(beta)
	auxiliary_random_mean<-Z0 %*% t(b)
	matrix_logit_mean<-auxiliary_fixed_mean+auxiliary_random_mean
	
	
	for (j in 1:lgrid)
	{
		WB_mean_mean[j,i]<-mean(1/(1+exp(-matrix_logit_mean[j,])),na.rm = TRUE)
		WB_sd_mean[j,i]<-sd(1/(1+exp(-matrix_logit_mean[j,])),na.rm=TRUE)
	}		}


### prediction from nonlinear parametric model + actual values
load('nonlin.Rdata')
cov1 = seq(0,1,length=lgrid)
cov2 = seq(0,1,length=lgrid)
phi.true = matrix(0,nrow=lgrid,ncol=lgrid)
phi.estim1 = matrix(0,nrow=lgrid,ncol=lgrid)
phi.estim2 = WB_mean_mean

for (i in 1:lgrid)
{
	for (j in 1:lgrid)
	{
		phi.true[i,j] = 1/(1+exp(-(0 + 0 * cov1[i] - 0.188 * cov2[j] + 0 * cov1[i]^2 - 0.220 * cov2[j]^2 + 0.5 * cov2[j] * cov2[j] 
							- 1.67 * cov1[i] * cov2[j])))
		
		phi.estim1[i,j] = 1/(1+exp(-(mean(mcmc[[1]][,'mu']) + mean(mcmc[[1]][,'beta[1]']) * cov1[i] + mean(mcmc[[1]][,'beta[2]']) * cov2[j] 
									 + mean(mcmc[[1]][,'beta[3]']) * cov1[i]^2 + mean(mcmc[[1]][,'beta[4]']) * cov2[j]^2 
									 + mean(mcmc[[1]][,'beta[5]']) * cov1[i] * cov2[j]))) # use posterior means and 1st chain
	}
}


### compare the actual survival, survival estimated from parametric model and survival estimated from splines model
par(mfrow=c(1,3))

image(cov1,cov2,phi.true,xlab=expression(x[1]),ylab=expression(x[2]),main='true survival') 
contour(cov1,cov2,phi.true,add=T) 
points(cov) 

image(cov1,cov2,phi.estim1,xlab=expression(x[1]),ylab=expression(x[2]),main='estimated quadratic surface') 
contour(cov1,cov2,phi.estim1,add=T) 
points(cov) 

image(cov1,cov2,phi.estim2,xlab=expression(x[1]),ylab=expression(x[2]),main='estimated nonparam survival') 
contour(cov1,cov2,phi.estim2,add=T) 
points(cov) 


