WinBUGS & R codes to run the semiparametric approach in:
Gimenez et al. (2006). Semiparametric regression in capture-recapture modelling. Biometrics.

"scriptR2WinBUGS.txt": the R script which reads in the data and calls WinBUGS
"splinesCJSenvironmental.bug": the associated WinBUGS code
"nnlin.dat": the data file (simulated data)
"output.pdf": the graphical outputs

Olivier Gimenez, January 26, 2006. StAndrews, Scotland.
