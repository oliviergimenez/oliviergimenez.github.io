WinBUGS & R codes to run the semiparametric approach in:
Gimenez et al. (2006). Nonparametric estimation of natural selection on a quantitative trait 
using capture-mark-recapture data. Evolution.

"scriptR2WinBUGS.txt": the R script which reads in the data and calls WinBUGS
"splinesCJSindividual.bug": the associated WinBUGS code
"data.dat": the data file (simulated data)
"output.pdf": the graphical outputs

Olivier Gimenez, January 26, 2006. StAndrews, Scotland.
