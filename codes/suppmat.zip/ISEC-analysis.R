## util functions
## function to perfom tm analysis
tm.anal <- function(abstract){
    library(tm)
    ## read file and build a corpus
    base <- Corpus(VectorSource(abstract), readerControl = list(language = "english",  load = TRUE))
    ## clean up; check out ?tm_map for details
    base2 <- tm_map(base, content_transformer(tolower))
    base2 <- tm_map(base2,removePunctuation, preserve_intra_word_dashes=T)
    base2 <- tm_map(base2, removeWords, stopwords("english")) 
    base2 <- tm_map(base2, removeWords, c('use','using','used','also','among','will','always','one','first','though','may','often','particular', "account", "additional", "allow", "approach", "assess", "available", "based", "can", "case", "combination", "combined", "combine", "common", "consider", "considered", "considers", "current", "depend", "depends", "describe", "describes", "described", "develop", "developped", "develops", "differ", "differs", "discuss", "discussed", "discusses", "general", "high", "however", "framework", "improves", "improved", "improve","includes", "include", "included", "invetsigate", "investigated", "large", "larger", "make", "mean", "number", "obtain", "need", "needs", "needed", "new", "order", "perform", "performs", "performed", "possible", "potential", "present", "problem", "propose", "proposed", "proposes", "provide", "provides", "provided", "potential", "related", "relate", "relates", "require", "requires", "required", "results", "result", "resulting", "set", "several", "similar", "size", "study", "studies", "source", "technique", "techniques", "three", "type", "two", "understand", "value", "values", "well", "within"))
    base2 <- tm_map(base2,stemDocument, language = "english") 
    base2 <- tm_map(base2,removeNumbers) 
    base2 <- tm_map(base2,stripWhitespace) 
    ## use appropriate format for further analyses
    dtm <- DocumentTermMatrix(base2)
    return(dtm)
}

## load the data
load("ISECData.rda")

## perform text mining analysis for each year separately
dtm2008 <- tm.anal(isec$abstract[isec$year == 2008])
dtm2010 <- tm.anal(isec$abstract[isec$year == 2010])
dtm2012 <- tm.anal(isec$abstract[isec$year == 2012])
dtm2014 <- tm.anal(isec$abstract[isec$year == 2014])


## get the 25 most used words
words2008 <- names(sort(colSums(as.matrix(dtm2008)), decreasing = TRUE)[1:25])
words2010 <- names(sort(colSums(as.matrix(dtm2010)), decreasing = TRUE)[1:25])
words2012 <- names(sort(colSums(as.matrix(dtm2012)), decreasing = TRUE)[1:25])
words2014 <- names(sort(colSums(as.matrix(dtm2014)), decreasing = TRUE)[1:25])

###############################################################
##                  Venn diagramm
###############################################################

## compute res that is the words by ISEC years incidence matrix
words.tot <- unique(c(words2008, words2010, words2012, words2014))
res <- matrix(0, nrow = length(words.tot), ncol = 4)
colnames(res) <- seq(2008, by = 2, length = 4)
rownames(res) <- words.tot
res[,1] <- words.tot%in%words2008
res[,2] <- words.tot%in%words2010
res[,3] <- words.tot%in%words2012
res[,4] <- words.tot%in%words2014
## reorder columns to plot them chronologically
res <- res[,c(1,4,2,3)]
library(VennDiagram)
venn.plot <- draw.quad.venn(
    area1 = 25,
    area2 = 25,
    area3 = 25,
    area4 = 25,
    n12 = sum(res[,1] * res[,2]),
    n13 = sum(res[,1] * res[,3]),
    n14 = sum(res[,1] * res[,4]),
    n23 = sum(res[,2] * res[,3]),
    n24 = sum(res[,2] * res[,4]),
    n34 = sum(res[,3] * res[,4]),
    n123 = sum(res[,1] * res[,2] * res[,3]),
    n124 = sum(res[,1] * res[,2] * res[,4]),
    n134 = sum(res[,1] * res[,3] * res[,4]),
    n234 = sum(res[,2] * res[,3] * res[,4]),
    n1234 = sum(res[,1] * res[,2] * res[,3] * res[,4]),
    category = colnames(res), 
    fill = c("orange", "red", "green", "blue"), 
    lty = "dashed",
    cat.cex = 2,
    cat.col = c("orange", "red", "green", "blue"),
    alpha = rep(0.5, 4),
    cex =2,
    ind = FALSE
    )

## modify labels to add terms
## 2010
venn.plot[[9]]$label <- paste(rownames(res)[(res[,3] == 1) & (rowSums(res[,-3]) ==0)], sep = "", collapse = "\n")
venn.plot[[9]]$gp$cex <- 1
## 2012
venn.plot[[11]]$label <- paste(rownames(res)[(res[,4] == 1) & (rowSums(res[,-4]) ==0)], sep = "", collapse = "\n")
venn.plot[[11]]$gp$cex <- 1
## 2008 & 2010
venn.plot[[12]]$label <- paste(rownames(res)[(res[,1] == 1 & res[,3] == 1) & (rowSums(res[,-c(1,3)]) ==0)], sep = "", collapse = "\n")
venn.plot[[12]]$gp$cex <- 1
## 2008 & 2010 & 2012
venn.plot[[13]]$label <- paste(rownames(res)[(res[,1] == 1 & res[,3] == 1 & res[,4] == 1) & !res[,2]], sep = "", collapse = "\n")
venn.plot[[13]]$gp$cex <- 1
## 2010 & 2012 & 2014
venn.plot[[15]]$label <- paste(rownames(res)[(res[,2] == 1 & res[,3] == 1 & res[,4] == 1) & !res[,1]], sep = "", collapse = "\n")
venn.plot[[15]]$gp$cex <- 1
## 2012 & 2014
venn.plot[[16]]$label <- paste(rownames(res)[(res[,2] == 1 & res[,4] == 1) & (rowSums(res[,-c(2,4)]) ==0)], sep = "", collapse = "\n")
venn.plot[[16]]$gp$cex <- 1
## 2008
venn.plot[[17]]$label <- paste(rownames(res)[(res[,1] == 1) & (rowSums(res[,-1]) ==0)], sep = "", collapse = "\n")
venn.plot[[17]]$gp$cex <- 1
## 2008 & 2010 & 2014
venn.plot[[20]]$label <- paste(rownames(res)[(res[,1] == 1 & res[,2] == 1 & res[,3] == 1) & !res[,4]], sep = "", collapse = "\n")
venn.plot[[20]]$gp$cex <- 1
## 2014
venn.plot[[22]]$label <- paste(rownames(res)[(res[,2] == 1) & (rowSums(res[,-2]) ==0)], sep = "", collapse = "\n")
venn.plot[[22]]$gp$cex <- 1

pdf("fig-venn.pdf")
grid.draw(venn.plot)
dev.off()

###############################################################
##                multivariate analysis
###############################################################

## get the 50 most used words
k <- 50
words2008 <- names(sort(colSums(as.matrix(dtm2008)), decreasing = TRUE)[1:k])
words2010 <- names(sort(colSums(as.matrix(dtm2010)), decreasing = TRUE)[1:k])
words2012 <- names(sort(colSums(as.matrix(dtm2012)), decreasing = TRUE)[1:k])
words2014 <- names(sort(colSums(as.matrix(dtm2014)), decreasing = TRUE)[1:k])
words.tot <- unique(c(words2008, words2010, words2012, words2014))

## compute the abstract per terms abundance matrix
ab2008 <- as.matrix(dtm2008)[,  dtm2008$dimnames[[2]]%in%words.tot]
ab2010 <- as.matrix(dtm2010)[,  dtm2010$dimnames[[2]]%in%words.tot]
ab2012 <- as.matrix(dtm2012)[,  dtm2012$dimnames[[2]]%in%words.tot]
ab2014 <- as.matrix(dtm2014)[,  dtm2014$dimnames[[2]]%in%words.tot]
ab <- rbind(ab2008, ab2010, ab2012, ab2014)
rownames(ab) <- 1:nrow(ab)

## compute the authors per abstract incidence matrix
n.abs.auth <- table(unlist(isec$coAuth))
auth.tot <- names(n.abs.auth)
auth.abs <- matrix(0, length(auth.tot), length(isec$abstract))

for(i in 1:length(isec$abstract))
    auth.abs[,i] <- auth.tot%in%isec$coAuth[[i]]

## non-symmetric correspondence analysis
library(ade4)
library(adegraphics) ## available on R-Forge by  install.packages("adegraphics", repos="http://R-Forge.R-project.org")

nsc1 <- dudi.nsc(t(ab), scannf = FALSE, nf = 5)
summary(nsc1)

## randomization test
randtest(bca(t(nsc1), isec$year, scannf = FALSE))
## compute inertia statistics to define the size of terms labels proprtional to their contribution
iner <- inertia.dudi(nsc1, row = TRUE, col = FALSE)

## plot results
pl1 <- s.label(nsc1$l1, plab.box.draw = F, ppoint.cex = 0, plab.cex = log(rowSums(iner$row.abs))/5 , plab.alpha = 0.7, xlim = c(-2,6), ylim = c(-4,4))
pl2 <- s.class(1.5*nsc1$co, isec$year, col = c('orange', 'green', 'blue', 'red'), star = 0, chull = 0.9, ell = 0, ppoint.cex = 0.6, ppoin.pch = 1:4, xlim = c(-2,6), ylim = c(-4,4))

pdf("fig-ANSC.pdf", width = 10, height = 5)
ADEgS(list(pl1,pl2), layout=c(1,2))
dev.off()

###############################################################
##                   Network analysis
###############################################################
library("igraph")
load('ISECGraph.rda') ## clustering is obtained using wmixnet (https://forge.agroparistech.fr/p/wmixnet/)
cluster <- apply(mat_appartenance,1, which.max )
graphtot <- graph.adjacency(adjtot, mode = "undirected")

## Vertex degree  
dg <- degree(graphtot)
n <- length(dg)
dg.norm <- dg/(n-1)

color.code <- c("blue", "orange1", "gray80", "red"   , "green",  
                "black" ,  "mediumorchid2"  , "deeppink", "yellow","steelblue3",
                "olivedrab4", "purple4", "darksalmon", "red4", rep("white", 3))
shape <- sort(rep(c("circle", "square"),8))

lcluster <- lapply(1:max(cluster), function(i) names(which(cluster==i)) )
graphCluster <- graph.adjacency(round(pi*1000), weighted=TRUE,diag=TRUE,mode="undirected") ## threshold for the community graph, avoiding confusing graph 
alpha <- apply(mat_appartenance,2, sum)
tiff(file="Fig-Graph.tiff", height=480, width=960)
par(mfrow=c(1,2), oma=c(0,0,0,0), mai=c(2,1,1,1), mar=c(2,1,1,1)+0.1)
plot(graphtot, layout=coord,  edge.color="grey60",  vertex.size=8*log(1.005+ dg.norm)/(max(log(1+ dg.norm))), 
     vertex.size2=1,
     vertex.label=NA,
     vertex.label.cex= 6*log(1.005+ dg.norm)/(max(log(1+ dg.norm))), 
     vertex.label.color="black", vertex.color=color.code[cluster], vertex.shape=shape[cluster], asp=1)
mtext(side=1, text="(a)", cex = 2)

plot(graphCluster, layout=coordCluster,  vertex.size2=1,
     vertex.size=5*log(alpha), edge.width=4*log(1+E(graphCluster)$weight/100),
     vertex.label.color="black", vertex.color=color.code[1:15], vertex.shape=shape[1:15], asp=1)
mtext(side=1, text="(b)", cex = 2)
dev.off()
